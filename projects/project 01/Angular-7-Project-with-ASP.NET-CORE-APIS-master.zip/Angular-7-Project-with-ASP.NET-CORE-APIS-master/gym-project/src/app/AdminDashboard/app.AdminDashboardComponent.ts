import { Component} from '@angular/core';

@Component({
    templateUrl:'./app.AdminDashboardComponent.html'
})

export class AdminDashboardComponent
{

}