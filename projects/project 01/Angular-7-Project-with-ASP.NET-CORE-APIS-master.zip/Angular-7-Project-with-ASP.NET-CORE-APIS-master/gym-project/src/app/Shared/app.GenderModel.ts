interface GenderModel
{
     id :string;
     Name :string;
}