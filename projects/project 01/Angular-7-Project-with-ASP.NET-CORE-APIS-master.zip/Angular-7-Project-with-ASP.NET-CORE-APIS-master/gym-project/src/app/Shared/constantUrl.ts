/** This file in future not longer referenced, apiEndPoint Reference from "environment/environment" */
export const constantUrl  =
{
  apiEndpoint: 'http://localhost:49749'
};
