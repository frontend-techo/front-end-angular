export class RoleModel {
    public RoleName: string;
    public Status: boolean;
    public RoleId : number;
}