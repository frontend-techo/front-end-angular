export class RequestMemberModel {
    public MemberName: string;
}