export class MemberDetailsReportModel
{
 public Name :string;
 public Address :string;
 public Contactno :string;
 public EmailID :string;
 public MemberNo :string;
 public PlanName :string;
 public SchemeName :string;
 public JoiningDate :string;
 public RenwalDate :string;
 public PaymentAmount :string;
}