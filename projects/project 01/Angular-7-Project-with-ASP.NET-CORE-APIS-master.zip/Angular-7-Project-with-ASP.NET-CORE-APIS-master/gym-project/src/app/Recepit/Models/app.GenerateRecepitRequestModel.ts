export class GenerateRecepitRequestModel 
{
    public PaymentID: number;
}